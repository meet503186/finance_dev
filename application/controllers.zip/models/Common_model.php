<?php

class Common_model extends CI_Model
{
	function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->library('session');
	}
	function getDistrictList()
	{
		$dist=array();
		if ($this->session->userdata("role")!="Superadmin")
		{
			$dist=$this->db->query("select district.* from assigneddistrict join district on assignedDistrictId=districtId  where assignedUserId='".$this->session->userdata("uid")."' order by districtName asc")->result_array();
		}
		else
		{
			$dist=$this->db->query("select * from district order by districtName asc")->result_array();
		}
	
		//secho $this->db->last_query()."<br>";
		//print_r($dist);
		return $dist;
	}
	
	function getMeetingList()
	{
		$dist=array();
		if ($this->session->userdata("role")!="Superadmin") {
			$dist=$this->db->query("select meeting.* from meeting where meetingId in (select meetId from meetingdistrict where meetingDistrictId in (select assignedDistrictId from assigneddistrict where assignedUserId='".$this->session->userdata("uid")."') )")->result_array();
		} else {
			$dist=$this->db->query("select * from meeting order by meetingId DESC")->result_array();
		}

		//secho $this->db->last_query()."<br>";
		//print_r($dist);
		return $dist;
	}
	function getAgendaDetail($agendacode="")
	{
		$data=$this->db->query("select * from tasks join meeting on taskMeetingId=meetingId join users on taskByID=id join department on taskDepartment=departmentId where taskCode='".$agendacode."'")->result_array();
	//	echo $this->db->last_query();
		return $data;
	}
	function createAgendaHistory($content="",$agendaid="")
	{
		$data["historyContent"]=$content;
		$data["historyUserId"]=$this->session->userdata("uid");
		$data["historyAgendaId"]=$agendaid;
		$this->db->insert("agendahistory",$data);
	}
	function timeAgo($date)
	{
		$last = new DateTime($date);
		$now = new DateTime( date( 'Y-m-d h:i:s', time() )) ;

		// Find difference
		$interval = $last->diff($now);

		// Store in variable to be used for calculation etc
		$years = (int)$interval->format('%Y');
		$months = (int)$interval->format('%m');
		$days = (int)$interval->format('%d');
		$hours = (int)$interval->format('%H');
		$minutes = (int)$interval->format('%i');

		//   $now = date('Y-m-d H:i:s');


		if ($years > 0) {
			echo $years.' Years '.$months.' Months '.$days.' Days '. $hours.' Hours '.$minutes.' minutes ago.' ;
		} else if ($months > 0) {
			echo $months.' Months '.$days.' Days '. $hours.' Hours '.$minutes.' minutes ago.' ;
		} else if ($days > 0) {
			if ($days==1)
			{
				echo 'Yesterday At '.date("h:i:a",strtotime($date)) ;
			}
			else
			{
				echo $days.' Days '.$hours.' Hours '.$minutes.' minutes ago.' ;
			}
			
		} else if ($hours > 0) {
			echo  $hours.' Hrs ago.' ;
		} else {
			echo $minutes.' minutes ago.' ;
		}
	}
	function getLoggedInUser()
	{
		$userdata=$this->db->query("select * from users where id=?", array($this->session->userdata("uid")))->result_array();
		return $userdata[0];
	}
	function getColoredStatus($status="")
	{
		if ($status=="Queue") {
			return '<span class="badge badge-primary">'.$status.'</span>';
		}
		if ($status=="Inprogress") {
			return $status;
		}
		if ($status=="Cancelled") {

			return '<span class="badge badge-danger">'.$status.'</span>';
		}
		if ($status=="Completed") {
			return '<span class="badge badge-success">'.$status.'</span>';
		}
	}
	function getAgendaButton($buttons=[],$agendacode)
	{
		$button="";
		foreach ($buttons as $data)
		{
			if ($data=="view")
			{
				$button.='<a href="'.base_url().'Admin/agendaDetailView/'.$agendacode.'" ><i style="margin:2px;" class="ti-eye btn btn-pink btn-flat"></i></a>';
			}
			if ($data=="edit") {
				$button.='<i style="margin:2px;" class="ti-pencil btn btn-warning  btn-flat"></i>';
			}
			if ($data=="delete") {
				$button.='<i style="margin:2px;" class="ti-trash btn btn-danger  btn-flat"></i>';
			}
		}
		return $button;;
	}
	function getMeetingButton($buttons=[], $id)
	{
		$button="";
		foreach ($buttons as $data) {
			if ($data=="view") {
				$button.='<a href="'.base_url().'Admin/agendaDetailView/'.$id.'" ><i style="margin:2px;" class="ti-eye btn btn-pink btn-flat"></i></a>';
			}
			if ($data=="edit") {
				$button.='<a href="'.base_url().'Admin/MeetingEditView/'.$id.'" ><i style="margin:2px;" class="ti-pencil btn btn-warning  btn-flat"></i></a>';
			}
			if ($data=="delete") {
				$button.='<i style="margin:2px;" class="ti-trash btn btn-danger  btn-flat"></i>';
			}
		}
		return $button;;
	}
	
	function getUserButton($buttons=[], $userid)
	{
		$button="";
		foreach ($buttons as $data) {
			if ($data=="view") {
				$button.='<a href="'.base_url().'Admin/userProfileView/'.$userid.'" ><i style="margin:2px;" class="ti-eye btn btn-pink btn-flat"></i></a>';
			}
			if ($data=="edit") {
				$button.='<i style="margin:2px;" class="ti-pencil btn btn-warning  btn-flat"></i>';
			}
			if ($data=="delete") {
				$button.='<i style="margin:2px;" class="ti-trash btn btn-danger  btn-flat"></i>';
			}
		}
		return $button;;
	}
	function getDepartmentButton($buttons=[], $departmentid)
	{
		$button="";
		if ($departmentid!=1)
		{
			foreach ($buttons as $data) {

				if ($data=="edit") {
					$button.='<a href="'.base_url().'Admin/DepartmentEditView/'.$departmentid.'" ><i style="margin:2px;" class="ti-pencil btn btn-warning  btn-flat"></i>';
				}
				if ($data=="delete") {
					$button.='<i style="margin:2px;" class="ti-trash btn btn-danger  btn-flat"></i>';
				}
			}
			return $button;;
		}
		else
		{
			return $button;
		}
		
	}
}
?>