 <div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">
	<div class="nano">
		<div class="nano-content">
			<ul>

				<li class="label">Main</li>
				<li class="<?php
				if ($page=="home") {
					echo "active";} ?>">
				<a href="<?=base_url() ?>Admin"><i class="ti-home"></i> Home </a>
				</li>
				<li class="<?php
					if ($page=="meetingList") {
					echo "active";} ?>">
				<a href="<?=base_url() ?>Admin/meetingListView"><i class="ti-view-list-alt"></i> Meeting </a></li>
				<li class="<?php
					if ($page=="agendaList") {
					echo "active";} ?>"><a href="<?=base_url() ?>Admin/agendaTask"><i class="ti-calendar"></i> Agenda </a></li>
					<?php
					if ($this->session->userdata("role")!="Department") {
						?>
						<li class="<?php
						if ($page=="userlist"&&$this->session->userdata("role")!="Departmen") {
							echo "active";} ?>"><a href="<?=base_url() ?>Admin/userlist"><i class="ti-user"></i> User </a></li>
						<?php
					}
					?>
					<?php
					if ($this->session->userdata("role")=="Superadmin") {
					?>
					<li class="<?php
					if ($page=="department") {
						echo "active";} ?>">
					<a href="<?=base_url() ?>Admin/department">	<i class="ti-layout-grid4-alt"></i> Department </a></li>
					<?php
				}
				?>
				

			</ul>
		</div>
	</div>
</div>