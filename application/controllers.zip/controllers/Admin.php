<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller
{
	function __construct()
	{
		parent::__construct();

		$this->load->database();
		$this->load->library('session');
		$this->load->library('pagination');
		
		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
		$this->output->set_header('Pragma: no-cache');
		$this->load->model('Common_model', 'commonmodel', TRUE);
		$this->load->model('User_model', 'usermodel', TRUE);
		$this->load->model('Task_model', 'agendaModel', TRUE);
		$this->load->model('Meeting_model', 'meetingModel', TRUE);
		$this->load->model('Department_model', 'departmentModel', TRUE);
		if ($this->session->userdata("role")=="") {
			redirect(base_url()."login", 'refresh');
		}
	}
	
	public function index()
	{
		$data["page"]="home";
		$this->load->view('include/header');
		$this->load->view('navigation',$data); 
		$this->load->view('include/topbarmenus'); 
		$this->load->view($this->session->userdata("role").'/dashboard',$data);
		$this->load->view('include/footer');
	}
	public function department()
	{
		$data["page"]="department";
		$this->load->view('include/header');
		$this->load->view('navigation',$data);
		$this->load->view('include/topbarmenus'); 
		$this->load->view('department');
		$this->load->view('include/footer');
	}
	
	public function userlist()
	{
		$data["page"]="userlist";
		$this->load->view('include/header');
		$this->load->view('navigation',$data);
		$this->load->view('include/topbarmenus');
		$this->load->view('userlist');
		$this->load->view('include/footer');
	}
	function getuserList()
	{
		$list = $this->usermodel->get_datatables();
		//print_r($list); die;
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $rowData) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $this->profilepic($rowData->id,$rowData->profilePicAt);
			$row[] = $rowData->name;
			$row[] = $rowData->email;
			$row[] = $rowData->loginaccess;
			$row[] = $rowData->duty;
			$row[] = $rowData->contact1;
			$row[]= $this->commonmodel->getUserButton(["view","edit","delete"],$rowData->taskCode);
			$actionstring="";
			


			$row[] = $actionstring;
			$data[] = $row;
		}

		$output = array(
		"draw" => $_POST['draw'],
		"recordsTotal" => $this->usermodel->count_all(),
		"recordsFiltered" => $this->usermodel->count_filtered(),
		"data" => $data,
		);
		// print_r($output);
		//output to json format
		echo json_encode($output);
	}
	function profilepic($userid="",$at="")
	{
		if (file_exists("profilePictures/".$userid.".jpg")) {
			return '<img class="avatar-img" src="'.base_url().'profilePictures/'.$userid.'.jpg?'.$at.'" alt="" />';
		
	} else {
		return '<img class="avatar-img" src="'.base_url().'assets/images/avatar/1.jpg" alt="" /> <span class="user-avatar">';
		
	}
	}
	public function adduserView()
	{
		$data["page"]="userlist";
		$this->load->view('include/header');
		$this->load->view('navigation',$data);
		$this->load->view('include/topbarmenus');
		$this->load->view('adduserView');
		$this->load->view('include/footer');
	}
	public function saveUser()
	{
		$checkdata=$this->db->get_where("users",array("email"=>$this->input->post("email")));
		if($checkdata->num_rows()==0)
		{
		
			if (!isset($_POST['distid']))
			{
				$responsedata["success"]=0;
				$responsedata["message"]="select district";
				echo json_encode($responsedata,TRUE);
				return;
			}
			else {
				
				if (count($_POST['distid'])>1&&($this->input->post("loginaccess")=="Department"||$this->input->post("loginaccess")=="Supporter")) {
					$responsedata["success"]=0;
					$responsedata["message"]="select single district for ".$this->input->post("loginaccess");
					echo json_encode($responsedata,TRUE);
					return;
				}
				else
				{
					$data["name"]=$this->input->post("name");
					$data["gender"]=$this->input->post("gender");
					$data["email"]=$this->input->post("email");
					$data["password"]=$this->input->post("password");
					$data["loginaccess"]=$this->input->post("loginaccess");
					$data["duty"]=$this->input->post("duty");
					$data["department"]=$this->input->post("department");
					$data["contact1"]=$this->input->post("contact1");
					$data["contact2"]=$this->input->post("contact2");
					$data["createdBy"]=$this->session->userdata("uid");
					
					$this->db->insert("users",$data);
					
					$lastid=$this->db->insert_id();
					
					foreach ($_POST['distid'] as $value) {

						$distdata["assignedUserId"]=$lastid;
						$distdata["assignedDistrictId"]=$value;
						$this->db->insert("assigneddistrict",$distdata);
						
					}
					
					$responsedata["success"]=1;
					echo json_encode($responsedata,true);
				}	
			}
		}
		else
		{
			$responsedata["success"]=0;
			$responsedata["message"]="user already exist with this email";
			echo json_encode($responsedata,TRUE);
		}
		
	}
	public function addDepartmentView()
	{
		$data["page"]="department";
		$this->load->view('include/header');
		$this->load->view('navigation',$data);
		$this->load->view('include/topbarmenus');
		$this->load->view('adddepartmentView');
		$this->load->view('include/footer');
	}
	public function saveDepartment()
	{
		$checkdata=$this->db->get_where("department",array("departmentName"=>$this->input->post("departmentName")));
		if ($checkdata->num_rows()==0) {
			$data["departmentName"]=$this->input->post("departmentName");
			
			$this->db->insert("department",$data);

			$responsedata["success"]=1;
			echo json_encode($responsedata,true);
		} else {
			$responsedata["success"]=0;
			$responsedata["message"]="department already exist";
			echo json_encode($responsedata,TRUE);
		}
	}
	public function updateDepartment()
	{
		$checkdata=$this->db->get_where("department",array("departmentName"=>$this->input->post("departmentName")));
		if ($checkdata->num_rows()>0) {
			$responsedata["success"]=0;
			$responsedata["message"]="department already exist";
			echo json_encode($responsedata,TRUE);
		} else {
			
			$data["departmentName"]=$this->input->post("departmentName");
			
			$this->db->where("departmentId",$this->input->post("departmentid"));
  
			$this->db->update("department",$data);

			$responsedata["success"]=1;
			echo json_encode($responsedata,true);
			
		}
	}
	public function agendaTask()
	{
		$data["page"]="agendaList";
		$this->load->view('include/header');
		$this->load->view('navigation',$data);
		$this->load->view('include/header');
		$this->load->view('navigation');
		$this->load->view('include/topbarmenus');
		$this->load->view('agendaTaskView');
		$this->load->view('include/footer');
	}
	public function addAgendaView()
	{
		$data["page"]="agendaList";
		$this->load->view('include/header');
		$this->load->view('navigation',$data);
		$this->load->view('include/topbarmenus');
		$this->load->view('addAgendaView');
		$this->load->view('include/footer');
	}
	
	public function saveAgenda()
	{
		$data["taskDate"]=$this->input->post("taskDate");
		$data["meetingName"]=$this->input->post("meetingTitle");
		$data["agendaTitle"]=$this->input->post("agendaTitle");
		$data["agendaDetail"]=$this->input->post("agendaDetail");
		$data["taskDepartment"]=$this->input->post("department");
		$data["taskByID"]=$this->session->userdata("uid");
		$data["taskMeetingId"]=$this->input->post("meeting");
		$data["taskCreatedDate"]=date("Y-m-d h:i:s");
		$data["taskStatus"]="Queue";
		
		$data["taskCode"]=md5(date("Y-mdh:i:s"));
		
		$this->db->insert("tasks",$data);

		$this->commonmodel->createAgendaHistory("Agenda created",$this->db->insert_id());
		$responsedata["success"]=1;
		echo json_encode($responsedata,true);
	}
	function getAgendaTaskList()
	{
		$list = $this->agendaModel->get_datatables();
		//print_r($list); die;
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $rowData) {
			$no++;
			$row = array();
			$row[] = $no;
			
			$row[] = $this->agendaLink($rowData->taskCode,date(DATEFORMATE,strtotime($rowData->taskDate)));
			$row[] = "".$rowData->meetingName;
			$row[] = $rowData->agendaTitle;
		
			$row[] = $rowData->name;
			$row[] = $rowData->departmentName;
			$row[] = date(DATEFORMATE,strtotime($rowData->meetingDate));
			$row[] = $this->commonmodel->getColoredStatus($rowData->taskStatus);
			$row[] = $this->commonmodel->getAgendaButton(["view","edit","delete"],$rowData->taskCode);
			$actionstring="";

			$row[] = $actionstring;
			$data[] = $row;
		}

		$output = array(
		"draw" => $_POST['draw'],
		"recordsTotal" => $this->agendaModel->count_all(),
		"recordsFiltered" => $this->agendaModel->count_filtered(),
		"data" => $data,
		);
		// print_r($output);
		//output to json format
		echo json_encode($output);
	}
	
	function agendaLink($code="",$data="")
	{
		return "<a href='".base_url()."Admin/agendaDetailView/".$code."' >".$data."</a>";
	}
	function getDepartmentList()
	{
		$list = $this->departmentModel->get_datatables();
		//print_r($list); die;
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $rowData) {
			$no++;
			$row = array();
			$row[] = $no;
		
			$row[] = $rowData->departmentName;
			$row[] = $this->commonmodel->getDepartmentButton(["edit","delete"],$rowData->departmentId);
			$actionstring="";



			$row[] = $actionstring;
			$data[] = $row;
		}

		$output = array(
		"draw" => $_POST['draw'],
		"recordsTotal" => $this->departmentModel->count_all(),
		"recordsFiltered" => $this->departmentModel->count_filtered(),
		"data" => $data,
		);
		// print_r($output);
		//output to json format
		echo json_encode($output);
	}
	public function meetingListView()
	{
		$data["page"]="meetingList";
		$this->load->view('include/header');
		$this->load->view('navigation',$data);
		$this->load->view('include/topbarmenus');
		$this->load->view('meetingListView');
		$this->load->view('include/footer');
	}
	public function createMeetingView()
	{
		$data["page"]="meetingList";
		$this->load->view('include/header');
		$this->load->view('navigation',$data);
		$this->load->view('include/topbarmenus');
		$this->load->view('createMeetingView');
		$this->load->view('include/footer');
	}
	public function profileView()
	{
		$this->load->view('include/header');
		$this->load->view('navigation');
		$this->load->view('include/topbarmenus');
		$this->load->view('profileView');
		$this->load->view('include/footer');
	}
	public function agendaDetailView($code="")
	{
		$data["agendacode"]=$code;
		$data["page"]="agendaList";
		$this->load->view('include/header');
		$this->load->view('navigation',$data);
		$this->load->view('include/header');
		$this->load->view('navigation');
		$this->load->view('include/topbarmenus');
		$this->load->view('agendaDetailView',$data);
		$this->load->view('include/footer');
	}
	
	
	public function saveMeeting()
	{
	

			if (!isset($_POST['distid'])) {
				$responsedata["success"]=0;
				$responsedata["message"]="select district";
				echo json_encode($responsedata,TRUE);
				return;
			} else {
				
					$data["meetingTitle"]=$this->input->post("title");
					$data["meetingDetail"]=$this->input->post("description");
					$data["meetingDate"]=$this->input->post("meetingDate");
					$data["meetingCreatedBy"]=$this->session->userdata("uid");
					$data["meetingStatus"]="opened";
					
					$this->db->insert("meeting",$data);

					$lastid=$this->db->insert_id();

					foreach ($_POST['distid'] as $value) {

						$distdata["meetId"]=$lastid;
						$distdata["meetingDistrictId"]=$value;
						$this->db->insert("meetingdistrict",$distdata);

					}

					$responsedata["success"]=1;
					echo json_encode($responsedata,true);
				
			}
		
	}
	public function updateMeeting()
	{

			$data["meetingTitle"]=$this->input->post("title");
			$data["meetingDetail"]=$this->input->post("description");
			$data["meetingDate"]=$this->input->post("meetingDate");
			$data["meetingCreatedBy"]=$this->session->userdata("uid");
			$data["meetingStatus"]=$this->input->post("meetstatus");
			$this->db->where("meetingId",$this->input->post("meetid"));
			$this->db->update("meeting",$data);
			$responsedata["success"]=1;
			echo json_encode($responsedata,true);

	}
	function getMeetingList()
	{
		$list = $this->meetingModel->get_datatables();
		//print_r($list); die;
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $rowData) {
			$no++;
			$row = array();
			$row[] = $no;

			$row[] = date(DATEFORMATE,strtotime($rowData->meetingDate));
			$row[] = $rowData->meetingTitle;
			$row[] = $rowData->meetingDetail;

			$row[] = $rowData->name;
			$row[] = $rowData->meetingStatus;
			$row[] = $row[]= $this->commonmodel->getMeetingButton(["edit","delete"],$rowData->meetingId);
			$actionstring="";



			$row[] = $actionstring;
			$data[] = $row;
		}

		$output = array(
		"draw" => $_POST['draw'],
		"recordsTotal" => $this->meetingModel->count_all(),
		"recordsFiltered" => $this->meetingModel->count_filtered(),
		"data" => $data,
		);
		// print_r($output);
		//output to json format
		echo json_encode($output);
	}
	
	public function uploadProfilePic()
	{
		$data = $_POST['image'];

		list($type, $data) = explode(';', $data);
		list(, $data)      = explode(',', $data);

		$data = base64_decode($data);
		$imageName = $this->session->userdata("uid").".jpg";
		file_put_contents('profilePictures/'.$imageName, $data);

		$qdata["profilePicAt"]=date("Y-m-d h:i:a");
		$this->db->where("id",$this->session->userdata("uid"));
		$this->db->update("users",$qdata);

		echo 'done';
	}
	public function saveRemarks()
	{
		if ($this->input->post("remarks")!="")
		{
			$data["remarksContent"]=$this->input->post("remarks");
			$data["remarksAgendaId"]=$this->input->post("agendaId");
			$data["remarksUserId"]=$this->session->userdata("uid");

			$this->db->insert("agendaremarks",$data);
			$this->commonmodel->createAgendaHistory("Remarks added- ".$this->input->post("remarks"),$this->input->post("agendaId"));
			$responsedata["success"]=1;
			echo json_encode($responsedata,true);
		}
		else
		{
			$responsedata["success"]=0;
			echo json_encode($responsedata,true);
		}
		
	}
	public function updateDeadLine($agendaid="")
	{
		if ($this->input->post("remarks")!=""&&$this->input->post("taskDate")) {
			$data["taskEndDate"]=$this->input->post("taskDate");
			$this->db->where("taskId",$agendaid);
			$this->db->update("tasks",$data);
			
			$this->commonmodel->createAgendaHistory("DeadLine changed to - ".date("d-m-Y",strtotime($this->input->post("taskDate")))."<br>Reason- ".$this->input->post("remarks"),$this->input->post("agendaId"));
			
			
			$data2["deadLineDate"]=date(MYSQLDATEFORMATE,strtotime($this->input->post("taskDate")));
			$data2["deadLineReason"]="DeadLine changed because,".$this->input->post("remarks");
			$data2["deadLineAgendaId"]=$agendaid;
			$data2["deadLineCreatedAt"]=date(MYSQLDATEFORMATE);
			$data2["deadLineUserId"]=$this->session->userdata("uid");

			$this->db->insert("agenda_deadline",$data2);
			
			
			$responsedata["success"]=1;
			echo json_encode($responsedata,true);
		} else {
			$responsedata["success"]=0;
			$responsedata["message"]="check deadline date and <br>Reason";
			echo json_encode($responsedata,true);
		}
	}
	public function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url()."login", 'refresh');
	}
	public function uploadAttachment()
	{
		$upload = 'err';
		
		if (!empty($_FILES['file_upload'])) {

			// File upload configuration
			$targetDir = "datafiles/";
			$allowTypes = array('pdf', 'doc', 'docx', 'jpg', 'png', 'jpeg', 'gif','ppt','pptx');

			$fileName = basename($_FILES['file_upload']['name']);
			$targetFilePath =$targetDir.$fileName;
			$newname=md5(date(MYSQLDATEFORMATE));
			//print_r($_FILES);
			// Check whether file type is valid
			
			$fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);
			$newname=$targetDir.$this->input->post("agendaid")."_".$newname.".".$fileType;
			if (in_array($fileType, $allowTypes)) {
				// Upload file to the server
				if (move_uploaded_file($_FILES['file_upload']['tmp_name'], $newname)) {
					$upload = 'ok';
					
					$data2["attachementName"]=$fileName;
					$data2["attachementAgendaId"]=$this->input->post("agendaid");
					$data2["attachementCreatedAt"]=date(MYSQLDATEFORMATE);
					$data2["attachementUserId"]=$this->session->userdata("uid");
					$data2["attachementUrl"]=$newname;
					$this->db->insert("agendaattachment",$data2);
					
				}
				
			}
		}
		echo $upload;
	}
	function MeetingEditView($meetingid)
	{
		$data["meetingid"]=$meetingid;
		$data["page"]="meetingList";
		$this->load->view('include/header');
		$this->load->view('navigation',$data);
		$this->load->view('include/header');
		$this->load->view('navigation');
		$this->load->view('include/topbarmenus');
		$this->load->view('MeetingEditView',$data);
		$this->load->view('include/footer');
	}
	function DepartmentEditView($departmentid)
	{
		$data["departmentid"]=$departmentid;
		$data["page"]="department";
		$this->load->view('include/header');
		$this->load->view('navigation',$data);
		$this->load->view('include/header');
		$this->load->view('navigation');
		$this->load->view('include/topbarmenus');
		$this->load->view('DepartmentEditView',$data);
		$this->load->view('include/footer');
	}
}
